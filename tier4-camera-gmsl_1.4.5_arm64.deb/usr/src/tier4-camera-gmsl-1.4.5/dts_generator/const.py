#!/usr/bin/env python3

from typing import Final

GPIO_ACTIVE_HIGH: Final[int] = 0
GPIO_ACTIVE_LOW: Final[int] = 1
